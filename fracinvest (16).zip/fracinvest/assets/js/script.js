$(document).ready( function() {

$('.Review_slider').slick({
  dots: true,
  infinite: true,
  speed: 300,
  arrows:false,
  slidesToShow: 3,
  slidesToScroll: 1,
  responsive: [
  {
      breakpoint: 1025,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 2
      }
    },
    {
      breakpoint: 767.5,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1
      }
    },
    {
      breakpoint: 600,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1
      }
    }
  ]
});


$('.Media_slider').slick({
  dots: false,
  arrows: true,
  infinite: true,
  speed: 300,
  slidesToShow: 3,
  slidesToScroll: 1,
  responsive: [
  {
      breakpoint: 1025,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 2
      }
    },
    {
      breakpoint: 991.5,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1
      }
    },
    {
      breakpoint: 600,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1
      }
    },
    {
      breakpoint: 480,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1
      }
    }
  ]
});

$('.list').click(function(event){
  event.preventDefault();
  $('#products .item').removeClass('grid-group-item');
  $('#products .item').addClass('list-group-item');
});
$('.grid').click(function(event){
  event.preventDefault();
  $('#products .item').removeClass('list-group-item');
  $('#products .item').addClass('grid-group-item');
});


function getVals(){
  // Get slider values
  var parent = this.parentNode;
  var slides = parent.getElementsByTagName("input");
    var slide1 = parseFloat( slides[0].value );
    // var slide2 = parseFloat( slides[1].value );
  // Neither slider will clip the other, so make sure we determine which is larger
  // if( slide1 > slide2 ){ var tmp = slide2; slide2 = slide1; slide1 = tmp; }
  
  var displayElement = parent.getElementsByClassName("rangeValues")[0];
      displayElement.innerHTML = slide1 + "% ";
      // displayElement.innerHTML = slide1 + "% " + slide2 + "%";
}

window.onload = function(){
  // Initialize Sliders
  var sliderSections = document.getElementsByClassName("range-slider");
      for( var x = 0; x < sliderSections.length; x++ ){
        var sliders = sliderSections[x].getElementsByTagName("input");
        for( var y = 0; y < sliders.length; y++ ){
          if( sliders[y].type ==="range" ){
            sliders[y].oninput = getVals;
            // Manually trigger event first time to display values
            sliders[y].oninput();
          }
        }
      }
}

// var delay = 500;
// $(".progress-bar").each(function(i){
//     $(this).delay( delay*i ).animate( { width: $(this).attr('aria-valuenow') + '%' }, delay );

//     $(this).prop('Counter',0).animate({
//         Counter: $(this).text()
//     }, {
//         duration: delay,
//         easing: 'swing',
//         step: function (now) {
//             $(this).text(Math.ceil(now)+'%');
//         }
//     });
// });


// LINE CHART 
var trace1 = {
  x: ['5 Dec', '10 Dec', '15 Dec', '20 Dec', '25 Dec', '30 Dec', '5 Jan'],
  y: [300,100,200,300,300,200,480],
  mode: 'lines+markers',
  marker: {
    color: '#AC6FFE',
    size: 8
  },
  line: {
    color: '#AC6FFE',
    width: 2
  }
};

var data = [ trace1];

var layout = {
    autosize: true,
    colorway : ['#2F55D4', '#2FC3D4'],
    showlegend: false,
    legend: {
        x: 0.8,
        y: 1
    },
    height: 300,
    margin: {
      l: 50,
      r: 10,
      b: 30,
      t: 10,
      pad: 10
    },
  };
  const config1 = {
    displayModeBar: false,
  };

Plotly.newPlot('lineChart', data, layout, {displayModeBar: false});
// END


// var xValues = ['5 Dec', '10 Dec', '15 Dec', '20 Dec', '25 Dec', '30 Dec', '5 Jan'];

// new Chart("myChart", {
//   type: "line",
  
//   data: {
//     labels: xValues,
//     datasets: [{ 
//       data: [300,100,200,300,300,200,480],
//       borderColor: "#AC6FFE",
//       fill: false,
//       pointRadius: 8,
//       pointBackgroundColor: "#AC6FFE",
//     }]
//   },
//   options: {
//     responsive: true,
//     legend: {
//       display: false
//     },
//     scales: {
//         xAxes: [{
//           display: true,
//           scaleLabel: {
//             display: true,
//           },
//           ticks: {
//               fontSize: 14,
//               family:'Inter'
//             }
//         }],
//         yAxes: [{
//           display: true,
//           scaleLabel: {
//               display: true,
//             },
//             ticks: {
//               min: 0,
//               max: 500,
//               stepSize: 100,
//               fontSize: 14,
//               family:'Inter',
//             }
//         }]
//       }
//   }
// });

});

  $(window).on('load', function() {
       setTimeout(function(){
        $('#fracModal').modal('show');
   }, 2000);
  });


